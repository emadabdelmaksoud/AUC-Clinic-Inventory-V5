# Inventory Engine (Transactions + Batches)

Stock is **derived**, not stored. The `products` table holds master data only.
On-hand quantities live in `inventory_batches` and are mutated **only** by
inserting rows into `inventory_transactions`.

## Tables

### `inventory_batches`
A physical lot of a product at a `(warehouse, section)`.

| Field | Notes |
|---|---|
| `product_id` | FK → `products` |
| `warehouse_id` | FK → `warehouses` |
| `section_id` | FK → `warehouse_sections` (nullable) |
| `batch_number` | Nullable text |
| `expiry_date` | Nullable date |
| `quantity_base_unit` | Maintained by triggers — do **not** edit directly |
| `created_at` / `updated_at` | Auto |

Identity: `(product, warehouse, section, batch_number, expiry_date)` is unique.
Different expiry dates ⇒ different batches.

FIFO index: `(product_id, warehouse_id, expiry_date NULLS LAST, created_at)`.

### `inventory_transactions` (append-only ledger)

| Field | Notes |
|---|---|
| `transaction_type` | `stock_in`, `dispensing`, `transfer_in`, `transfer_out`, `disposal`, `adjustment`, `inventory_count` |
| `product_id`, `batch_id`, `warehouse_id`, `section_id` | FKs |
| `quantity` | In `unit_id`'s unit (must be > 0) |
| `unit_id` | FK → `product_units` (must belong to same product) |
| `quantity_base_unit` | Computed by trigger: `quantity * unit.factor_to_base` |
| `performed_by` | Defaults to `auth.uid()` |
| `notes` | Free text |

## Sign convention

| Type | Effect on batch |
|---|---|
| `stock_in`, `transfer_in`, `adjustment` | `+ quantity_base_unit` |
| `dispensing`, `transfer_out`, `disposal` | `- quantity_base_unit` |
| `inventory_count` | sets batch to absolute `quantity_base_unit` |

`batch_id` is **required** for every transaction.

## Aggregated view

`public.stock_on_hand` — `(product_id, warehouse_id, section_id, quantity_base_unit)`
summing all batches. Uses `security_invoker = true` so RLS of the caller applies.

## RLS

- **batches**: any authenticated user can read & insert; updates/deletes are admin-only (mutations happen via transactions).
- **transactions**: any authenticated user can read & insert; only admins can delete.

## Multi-unit support

All math runs in **base units** (`product_units.is_base = true`). Users can
record transactions in any unit; the trigger normalises via `factor_to_base`.

## Client API (`src/lib/inventory.ts`)

```ts
import {
  upsertBatch,
  recordTransaction,
  listTransactions,
  getStockOnHand,
  getFifoBatches,
} from "@/lib/inventory";

// 1) Receive 2 cartons of Paracetamol into Main WH, batch ABC, expiry 2027-01-01
const batch = await upsertBatch({
  product_id, warehouse_id, section_id,
  batch_number: "ABC", expiry_date: "2027-01-01",
});
await recordTransaction({
  transaction_type: "stock_in",
  product_id, warehouse_id, section_id,
  batch_id: batch.id,
  quantity: 2,
  unit_id: cartonUnitId,        // any unit of the product
  notes: "PO-123",
});

// 2) Dispense 5 tablets FIFO
const [first] = await getFifoBatches(product_id, warehouse_id);
await recordTransaction({
  transaction_type: "dispensing",
  product_id, warehouse_id, batch_id: first.id,
  quantity: 5, unit_id: tabletUnitId,
});

// 3) Stock on hand
const stock = await getStockOnHand({ product_id });
```

## Rules enforced

- `quantity > 0` (use the correct type, never negative numbers).
- `unit_id` must belong to `product_id`.
- `batch_id` must belong to the same product **and** warehouse.
- Batch quantities can never go below 0 (check constraint).
- Stock is never edited directly — only through transactions.
