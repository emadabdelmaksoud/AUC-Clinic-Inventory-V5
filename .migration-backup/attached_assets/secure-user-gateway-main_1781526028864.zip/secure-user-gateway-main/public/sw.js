/* Clinic Inventory Hub — Service Worker
 * Strategy:
 *  - Precache app shell (offline fallback page + manifest)
 *  - HTML navigations: NetworkFirst with offline fallback
 *  - Static assets (JS/CSS/fonts/images): StaleWhileRevalidate
 *  - Supabase / API calls: NetworkOnly (never cached)
 *  - skipWaiting on SKIP_WAITING message → enables update workflow
 */

const VERSION = "v1.0.0";
const STATIC_CACHE = `static-${VERSION}`;
const RUNTIME_CACHE = `runtime-${VERSION}`;
const HTML_CACHE = `html-${VERSION}`;

const APP_SHELL = ["/offline.html", "/manifest.webmanifest"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => cache.addAll(APP_SHELL)).catch(() => {}),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((k) => ![STATIC_CACHE, RUNTIME_CACHE, HTML_CACHE].includes(k))
          .map((k) => caches.delete(k)),
      );
      await self.clients.claim();
    })(),
  );
});

self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting();
  }
});

function isApiRequest(url) {
  return (
    url.pathname.startsWith("/api/") ||
    url.hostname.includes("supabase.co") ||
    url.hostname.includes("supabase.in")
  );
}

function isStaticAsset(request, url) {
  const dest = request.destination;
  if (["style", "script", "font", "image", "worker"].includes(dest)) return true;
  return /\.(?:js|css|woff2?|ttf|otf|png|jpg|jpeg|webp|svg|ico)$/i.test(url.pathname);
}

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin && !isApiRequest(url) && !isStaticAsset(request, url)) {
    return;
  }
  if (isApiRequest(url)) return; // bypass — let app handle online/offline

  if (request.mode === "navigate") {
    event.respondWith(networkFirstHTML(request));
    return;
  }
  if (isStaticAsset(request, url) && url.origin === self.location.origin) {
    event.respondWith(staleWhileRevalidate(request));
  }
});

async function networkFirstHTML(request) {
  const cache = await caches.open(HTML_CACHE);
  try {
    const fresh = await fetch(request);
    if (fresh && fresh.ok) cache.put(request, fresh.clone());
    return fresh;
  } catch {
    const cached = await cache.match(request);
    if (cached) return cached;
    const offline = await caches.match("/offline.html");
    return offline || new Response("Offline", { status: 503, statusText: "Offline" });
  }
}

async function staleWhileRevalidate(request) {
  const cache = await caches.open(RUNTIME_CACHE);
  const cached = await cache.match(request);
  const network = fetch(request)
    .then((response) => {
      if (response && response.ok) cache.put(request, response.clone());
      return response;
    })
    .catch(() => undefined);
  return cached || (await network) || new Response("", { status: 504 });
}

// Background sync stub — clients can post {type:'SYNC'} after reconnect
self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SYNC") {
    event.waitUntil(
      self.clients.matchAll({ includeUncontrolled: true }).then((clients) => {
        clients.forEach((c) => c.postMessage({ type: "SYNC_REQUESTED" }));
      }),
    );
  }
});
