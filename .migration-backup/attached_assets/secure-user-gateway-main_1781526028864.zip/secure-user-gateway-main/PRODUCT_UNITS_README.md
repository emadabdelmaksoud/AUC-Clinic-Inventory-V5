# Multi-Unit Management

Each product has 1..N units stored in `product_units`. Exactly one row per
product is the **base unit** (`is_base = true`, `factor_to_base = 1`).
Every other unit stores how many **base units** it equals.

## Example: tablet product

| Unit    | factor_to_base | is_base | Means                         |
| ------- | -------------- | ------- | ----------------------------- |
| Tablet  | 1              | ✅      | base                          |
| Strip   | 10             |         | 1 strip  = 10 tablets         |
| Box     | 100            |         | 1 box    = 10 strips          |
| Carton  | 2400           |         | 1 carton = 24 boxes           |

## Conversion formula

```
qty_in_B = qty_in_A * (A.factor_to_base / B.factor_to_base)
```

Implemented in:

- TypeScript: `convertUnits(qty, fromUnit, toUnit)` in `src/lib/product-units.ts`
- SQL: `public.convert_units(from_unit_id, to_unit_id, qty)` in migration `0005`

Both refuse to convert across different products.

## Schema (`db/migrations/0005_product_units.sql`)

```
product_units (
  id, product_id → products.id,
  unit_name, factor_to_base (> 0), is_base,
  barcode, sort_order, created_at, updated_at,
  unique (product_id, unit_name),
  unique (product_id, barcode) deferrable
)
```

Invariants enforced in the DB:

- Only **one** `is_base = true` per product (partial unique index).
- A base unit **must** have `factor_to_base = 1` (BEFORE trigger).
- `factor_to_base > 0` (CHECK).
- Unit name unique per product; barcode unique per product when set.
- Backfill: every existing product gets a base unit auto-created from
  `products.base_unit` so the catalog stays consistent.

## RLS

- All authenticated users can **read** units.
- Admins or the product's `created_by` can insert / update / delete units.

## CRUD API (`src/lib/product-units.ts`)

| Function                                        | Purpose                          |
| ----------------------------------------------- | -------------------------------- |
| `listProductUnits(productId)`                   | List units for a product         |
| `createProductUnit(productId, input)`           | Add a unit                       |
| `updateProductUnit(id, input)`                  | Edit a unit                      |
| `deleteProductUnit(id)`                         | Remove a unit                    |
| `findUnitByBarcode(barcode)`                    | Scan: resolve barcode → unit+product |
| `convertUnits(qty, from, to)`                   | Cross-unit qty conversion        |
| `toBase(qty, unit)` / `fromBase(qtyBase, unit)` | Helpers for inventory module     |

All inputs validated with Zod (`productUnitSchema`, `.strict()`).

## UI (`src/components/products/product-units-manager.tsx`)

Mounted on the product details page (`/products/:id`). Includes:

- Units table with `base` badge, factor, human-readable equivalence, barcode.
- Add / edit / delete forms with the base-unit toggle (auto-locks
  `factor_to_base = 1` and prevents adding a second base).
- Live **conversion calculator** for any two units of the product.

## Dispensing & inventory (future)

Inventory rows will store quantities **in the base unit**. UI lets users
pick any unit when dispensing or receiving — the lib helpers
`toBase` / `fromBase` perform the conversion before write/read. Barcode
scans go through `findUnitByBarcode` to identify both the product and
the unit being handled (e.g. scanning a box barcode vs a strip barcode
on the same product).
