# Products Management Module

## Architecture

`products` is a **master catalog** of distinct products. One row per real-world
product (identified by name + manufacturer, or barcode, or product_code).

The following are **explicitly NOT** in the `products` table and must never
be added to it:

- ❌ `expiry_date` / `expires_at`
- ❌ `batch_number` / `batch_no` / `lot_number`
- ❌ `quantity` / `qty` / `stock` / `stock_on_hand`

These belong in a future `inventory_batches` table, where each row represents
one received batch of a master product (with its own expiry, batch number,
and quantity on hand). Migration `0004_products_master_guard.sql` installs a
DDL event trigger that blocks anyone from re-introducing those columns on
`public.products`.

### Products columns (the only ones allowed)

| Column          | Purpose                                |
| --------------- | -------------------------------------- |
| `id`            | UUID primary key                       |
| `product_code`  | Auto-generated `PRD-000001` if blank   |
| `product_name`  | Display name (Arabic-friendly)         |
| `barcode`       | Unique GTIN/EAN/etc.                   |
| `category`      | Free-form category                     |
| `manufacturer`  | Free-form manufacturer                 |
| `base_unit`     | unit / box / ml / mg …                 |
| `reorder_level` | Threshold for low-stock alerts (≥ 0)   |
| `notes`         | Free-form notes                        |
| `image_url`     | Public URL in `product-images` bucket  |
| `created_by`    | `auth.users.id` of creator             |
| `created_at`    | timestamptz                            |
| `updated_at`    | timestamptz (auto via trigger)         |

## Duplicate prevention

Two products are considered the **same master product** when any of these match:

- same `product_code` (unique)
- same `barcode` (unique)
- same `(product_name, manufacturer)` (unique composite)

Different expiry dates or different batch numbers **do NOT** create a new
product row — they will create new rows in `inventory_batches` that reference
the same `products.id`.

## Setup

1. Create a Supabase project (or use Lovable Cloud).
2. Copy `.env.example` → `.env` and fill in your URL + keys.
3. In Supabase SQL editor, run migrations in order:
   - `db/migrations/0001_auth_roles.sql`
   - `db/migrations/0002_products.sql`
   - `db/migrations/0003_storage.sql`
   - `db/migrations/0004_products_master_guard.sql`
4. `bun install && bun run dev`

## Roles

- `nurse` (default for new signups) — read/create products
- `admin` — full CRUD + delete

Promote to admin:

```sql
insert into public.user_roles (user_id, role)
values ('<auth-user-uuid>', 'admin')
on conflict do nothing;
```

## Validation (`src/lib/products.ts`)

Zod schema only accepts the master-catalog fields above. Any attempt to pass
`expiry_date`, `batch_number`, or `quantity` from a form is rejected at the
validation layer before it reaches Supabase.

## Features

- Auth (email/password) with session persistence
- Protected `/products` routes under `_authenticated` layout
- CRUD + image upload to public `product-images` bucket
- Live search (name / code / barcode / manufacturer / category) + autocomplete dropdown
- Category filter, Arabic-friendly inputs (`dir="auto"`), dark-mode via existing tokens

## Next step (not in this module)

Create `inventory_batches`:

```sql
create table public.inventory_batches (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete restrict,
  batch_number text,
  expiry_date date,
  quantity integer not null default 0 check (quantity >= 0),
  received_at timestamptz not null default now(),
  created_by uuid references auth.users(id),
  unique (product_id, batch_number)
);
```

All quantity/expiry queries (low-stock, expiring-soon) join through
`product_id` back to `products`.
