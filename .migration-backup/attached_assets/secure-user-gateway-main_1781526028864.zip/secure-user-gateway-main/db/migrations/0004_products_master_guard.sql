-- =========================================================
-- 0004_products_master_guard.sql
-- Enforce: products = MASTER catalog only.
-- Expiry dates, batch numbers, and quantities MUST NOT live here.
-- They will be handled by a future `inventory_batches` table.
-- =========================================================

-- Defensive cleanup: if a previous build accidentally added any of these
-- columns to public.products, drop them. This migration is idempotent.
alter table public.products drop column if exists expiry_date;
alter table public.products drop column if exists expires_at;
alter table public.products drop column if exists batch_number;
alter table public.products drop column if exists batch_no;
alter table public.products drop column if exists lot_number;
alter table public.products drop column if exists quantity;
alter table public.products drop column if exists qty;
alter table public.products drop column if exists stock;
alter table public.products drop column if exists stock_on_hand;

-- Block re-introduction of those columns via an event trigger.
create or replace function public.products_block_inventory_columns()
returns event_trigger language plpgsql as $$
declare
  r record;
  forbidden text[] := array[
    'expiry_date','expires_at',
    'batch_number','batch_no','lot_number',
    'quantity','qty','stock','stock_on_hand'
  ];
  col text;
begin
  for r in
    select objid::regclass::text as relname
    from pg_event_trigger_ddl_commands()
    where object_type = 'table' and schema_name = 'public'
  loop
    if r.relname = 'public.products' then
      foreach col in array forbidden loop
        if exists (
          select 1 from information_schema.columns
          where table_schema='public' and table_name='products' and column_name=col
        ) then
          raise exception
            'products is a MASTER catalog. Column "%" belongs in inventory_batches, not products.', col;
        end if;
      end loop;
    end if;
  end loop;
end; $$;

drop event trigger if exists products_block_inventory_columns_trg;
create event trigger products_block_inventory_columns_trg
  on ddl_command_end when tag in ('CREATE TABLE','ALTER TABLE')
  execute function public.products_block_inventory_columns();

comment on table public.products is
  'Master product catalog. Identity, barcode, category, manufacturer, base_unit, reorder_level, notes only. Expiry/batch/quantity live in inventory_batches (future).';
