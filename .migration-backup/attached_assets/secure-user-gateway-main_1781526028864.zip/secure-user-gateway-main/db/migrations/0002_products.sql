-- =========================================================
-- 0002_products.sql — Products master catalog
-- (expiry/batches live in a separate inventory table — NOT here)
-- =========================================================
create extension if not exists pg_trgm;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  product_code text not null unique,
  product_name text not null,
  barcode text unique,
  category text,
  manufacturer text,
  base_unit text not null default 'unit',
  reorder_level integer not null default 0 check (reorder_level >= 0),
  notes text,
  image_url text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint products_name_manufacturer_unique unique (product_name, manufacturer)
);

create index if not exists products_name_trgm_idx on public.products using gin (product_name gin_trgm_ops);
create index if not exists products_category_idx on public.products (category);
create index if not exists products_manufacturer_idx on public.products (manufacturer);
create index if not exists products_barcode_idx on public.products (barcode);

drop trigger if exists products_set_updated_at on public.products;
create trigger products_set_updated_at before update on public.products
  for each row execute function public.set_updated_at();

create sequence if not exists public.product_code_seq start with 1;

create or replace function public.generate_product_code()
returns trigger language plpgsql as $$
begin
  if new.product_code is null or length(trim(new.product_code)) = 0 then
    new.product_code := 'PRD-' || lpad(nextval('public.product_code_seq')::text, 6, '0');
  end if;
  return new;
end; $$;

drop trigger if exists products_autocode on public.products;
create trigger products_autocode before insert on public.products
  for each row execute function public.generate_product_code();

alter table public.products enable row level security;

drop policy if exists "products_read_authenticated" on public.products;
create policy "products_read_authenticated" on public.products
  for select to authenticated using (true);

drop policy if exists "products_insert_authenticated" on public.products;
create policy "products_insert_authenticated" on public.products
  for insert to authenticated with check (auth.uid() is not null);

drop policy if exists "products_update_admin_or_owner" on public.products;
create policy "products_update_admin_or_owner" on public.products
  for update to authenticated
  using (public.has_role(auth.uid(), 'admin') or created_by = auth.uid())
  with check (public.has_role(auth.uid(), 'admin') or created_by = auth.uid());

drop policy if exists "products_delete_admin" on public.products;
create policy "products_delete_admin" on public.products
  for delete to authenticated using (public.has_role(auth.uid(), 'admin'));
