-- =========================================================
-- 0005_product_units.sql — Multi-unit management
--
-- Each product has 1..N units. Exactly one row per product is the BASE
-- unit (factor_to_base = 1). Every other unit stores how many BASE units
-- it equals. Example for a tablet product:
--   Tablet   factor_to_base = 1        (is_base = true)
--   Strip    factor_to_base = 10       (1 strip  = 10 tablets)
--   Box      factor_to_base = 100      (1 box    = 10 strips * 10)
--   Carton   factor_to_base = 2400     (1 carton = 24 boxes * 100)
--
-- Quantity conversion between any two units of the same product:
--   qty_in_B = qty_in_A * (A.factor_to_base / B.factor_to_base)
-- =========================================================

create table if not exists public.product_units (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  unit_name text not null,
  factor_to_base numeric(20,6) not null check (factor_to_base > 0),
  is_base boolean not null default false,
  barcode text,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (product_id, unit_name),
  unique (product_id, barcode) deferrable initially deferred
);

-- Only one base unit per product, and the base must have factor 1.
create unique index if not exists product_units_one_base_per_product
  on public.product_units (product_id) where is_base = true;

create or replace function public.product_units_validate()
returns trigger language plpgsql as $$
begin
  if new.is_base and new.factor_to_base <> 1 then
    raise exception 'Base unit must have factor_to_base = 1 (got %)', new.factor_to_base;
  end if;
  if new.barcode is not null and length(trim(new.barcode)) = 0 then
    new.barcode := null;
  end if;
  return new;
end; $$;

drop trigger if exists product_units_validate_trg on public.product_units;
create trigger product_units_validate_trg
  before insert or update on public.product_units
  for each row execute function public.product_units_validate();

drop trigger if exists product_units_set_updated_at on public.product_units;
create trigger product_units_set_updated_at before update on public.product_units
  for each row execute function public.set_updated_at();

create index if not exists product_units_product_idx on public.product_units (product_id);
create index if not exists product_units_barcode_idx on public.product_units (barcode);

-- Backfill: create a base unit row for every existing product using
-- products.base_unit, so the catalog is consistent.
insert into public.product_units (product_id, unit_name, factor_to_base, is_base, sort_order)
select p.id, coalesce(nullif(trim(p.base_unit), ''), 'unit'), 1, true, 0
from public.products p
where not exists (
  select 1 from public.product_units u where u.product_id = p.id and u.is_base
);

-- RLS
alter table public.product_units enable row level security;

drop policy if exists "product_units_read_authenticated" on public.product_units;
create policy "product_units_read_authenticated" on public.product_units
  for select to authenticated using (true);

drop policy if exists "product_units_write_admin_or_owner" on public.product_units;
create policy "product_units_write_admin_or_owner" on public.product_units
  for all to authenticated
  using (
    public.has_role(auth.uid(), 'admin')
    or exists (
      select 1 from public.products p
      where p.id = product_units.product_id and p.created_by = auth.uid()
    )
  )
  with check (
    public.has_role(auth.uid(), 'admin')
    or exists (
      select 1 from public.products p
      where p.id = product_units.product_id and p.created_by = auth.uid()
    )
  );

-- Convenience: convert a quantity between two unit ids of the same product.
create or replace function public.convert_units(
  _from_unit uuid, _to_unit uuid, _qty numeric
) returns numeric language plpgsql stable as $$
declare
  f_factor numeric; t_factor numeric;
  f_product uuid; t_product uuid;
begin
  select factor_to_base, product_id into f_factor, f_product
    from public.product_units where id = _from_unit;
  select factor_to_base, product_id into t_factor, t_product
    from public.product_units where id = _to_unit;
  if f_factor is null or t_factor is null then
    raise exception 'Unknown unit id';
  end if;
  if f_product <> t_product then
    raise exception 'Cannot convert between units of different products';
  end if;
  return _qty * (f_factor / t_factor);
end; $$;

comment on table public.product_units is
  'Units a product can be sold/stocked/dispensed in. Exactly one base unit per product (factor_to_base=1). All quantities convert through factor_to_base.';
